#ifndef C_MAKTABKHONE_PROJECTHEADERS_H
#define C_MAKTABKHONE_PROJECTHEADERS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NUMBERS_SIZE 300
#define MAX_LENGTH 200
#define BASED_NUM_CHAR_CODE 48

#endif //C_MAKTABKHONE_PROJECTHEADERS_H
